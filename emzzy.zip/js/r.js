var auto_refresh = setInterval(
function()
{
$('#online').fadeOut('slow').load(' #online').fadeIn("slow");
$('#days').fadeOut('slow').load(' #days').fadeIn("slow");
$('#acc').fadeOut('slow').load(' #acc').fadeIn("slow");
$('#invest').fadeOut('slow').load(' #invest').fadeIn("slow");
}, 10000);