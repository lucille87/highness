function calcthis(a)

{ 

var perc = document.getElementById("percent").value;



if (a==1) { 

if (perc == "perc1") {document.getElementById('ress').innerHTML="Your <b>Profit</b> after 10 days";};

if (perc == "perc2") {document.getElementById('ress').innerHTML="Your <b>Profit</b> after 120 days";};

if (perc == "perc3") {document.getElementById('ress').innerHTML="Your <b>Profit</b> after 120 days";};

if (perc == "perc4") {document.getElementById('ress').innerHTML="Your <b>Profit</b> after 25 days";};

if (perc == "perc5") {document.getElementById('ress').innerHTML="Your <b>Profit</b> after 37 days";};

if (perc == "perc6") {document.getElementById('ress').innerHTML="Your <b>Profit</b> after 55 days";};

if (perc == "perc7") {document.getElementById('ress').innerHTML="Your <b>Profit</b> after 10 days";};

}



























var planperc=new Array(0,0,0,0,0,0);

var depo = document.getElementById("deposit").value;



if (perc == "perc1") {planperc=Array(226 , 226 , 226 , 226 , 226); min=10; max=200;};

if (perc == "perc2") {planperc=Array(248 , 248 , 248 , 248 , 248); min=201; max=500;};

if (perc == "perc3") {planperc=Array(260 , 260 , 260 , 260 , 260); min=501; max=1000;};

if (perc == "perc4") {planperc=Array(262 , 262 , 262 , 262 , 262); min=1001; max=25000;};

if (perc == "perc5") {planperc=Array(110 , 110 , 110 , 110 , 110); min=10; max=499;};

if (perc == "perc6") {planperc=Array(140 , 140 , 140 , 140 , 140); min=500; max=25000;};



if (depo < min)

  {

	document.getElementById("inpvar1").innerHTML = "n/a";

	document.getElementById("inpvar2").innerHTML = "n/a";						

	alert ("Minimal deposit is $"+min);	

  } 

else

if (depo > max)

  {

	document.getElementById("inpvar1").innerHTML = "n/a";

	document.getElementById("inpvar2").innerHTML = "n/a";						

	alert ("Maximal deposit is $"+max);	

  } 

  

else

  {



	  document.getElementById("inpvar1").innerHTML = planperc[0];

	  document.getElementById("inpvar2").innerHTML = planperc[0] * depo / 100;

	  document.getElementById("inpvar3").innerHTML = (planperc[0] * depo / 100 - depo).toFixed(2);

	

	if ( depo >=250)

	  {

		document.getElementById("inpvar1").innerHTML = planperc[1];

		document.getElementById("inpvar2").innerHTML = planperc[1] * depo / 100;

	  document.getElementById("inpvar3").innerHTML = planperc[1] * depo / 100 - depo;

		if ( depo >= 500)

		  {

			document.getElementById("inpvar1").innerHTML = planperc[2];

			document.getElementById("inpvar2").innerHTML = planperc[2] * depo / 100;

	  document.getElementById("inpvar3").innerHTML = planperc[2] * depo / 100 - depo;

			if ( depo >= 1000)

			  {

				document.getElementById("inpvar1").innerHTML = planperc[3];

				document.getElementById("inpvar2").innerHTML = planperc[3] * depo / 100;

	  document.getElementById("inpvar3").innerHTML = planperc[3] * depo / 100 - depo;

				if ( depo >= 5000)

				  {

					document.getElementById("inpvar1").innerHTML = planperc[4];

					document.getElementById("inpvar2").innerHTML = planperc[4] * depo / 100;

	  document.getElementById("inpvar3").innerHTML = planperc[4] * depo / 100 - depo;

				  }

			  }

		  }

	  }

  }



}