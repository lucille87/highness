<?php /* Smarty version 3.1.27, created on 2018-05-18 12:59:15
         compiled from "/home/ethgrhjj/investbiliecoin.club/tmpl/footer.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:2896360365aff066309e618_57136090%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0588f3d60b5c438fa90656ce954c9ba1473259c4' => 
    array (
      0 => '/home/ethgrhjj/investbiliecoin.club/tmpl/footer.tpl',
      1 => 1455751158,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2896360365aff066309e618_57136090',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5aff06630a0a15_37199916',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5aff06630a0a15_37199916')) {
function content_5aff06630a0a15_37199916 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '2896360365aff066309e618_57136090';
?>

</td>

  </tr>

</table>

<p>












</td>



  </tr>



</table>  



<br>



<center>


<?php echo $_smarty_tpl->getSubTemplate ("footer2.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>