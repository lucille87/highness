<?php /* Smarty version 3.1.27, created on 2018-05-14 15:17:47
         compiled from "/home/demozwni/hyips.demoscripts.website/tmpl/mheader.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:810565525af9e0dba22f56_71454564%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '305a56afa8a5a4224837f9401c505052737e7d5c' => 
    array (
      0 => '/home/demozwni/hyips.demoscripts.website/tmpl/mheader.tpl',
      1 => 1455766558,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '810565525af9e0dba22f56_71454564',
  'variables' => 
  array (
    'userinfo' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5af9e0dba2b4e9_88744135',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5af9e0dba2b4e9_88744135')) {
function content_5af9e0dba2b4e9_88744135 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/demozwni/hyips.demoscripts.website/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '810565525af9e0dba22f56_71454564';
echo $_smarty_tpl->getSubTemplate ("logo.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

<div class="diracc dirtxt">Dear <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['userinfo']->value['username']);?>
 , Welcome to your account area
    <br>
    <a class="dirbtn" href="?a=edit_account">account settings</a> <a class="dirbtnm" href="?a=logout">logout</a></div>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="1349">
  <tr>
    <td width="100%" class="directory"><center>
    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="1200">
      <tr>
        <td width="100%">        
        <div class="dirurl"><a class="dirlink" href="index.php?a=account">My account</a> / Information</div>
        </td>
      </tr>
    </table>
    </td>
  </tr>
</table>
<br>

<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="1200">
  <tr>
    <td width="75" class="accmenu" valign="top"><table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="215" height="169">

  <tr>

    <td width="100%" height="17">

    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber1">

      <tr>

        <td width="100%" class="leftmenu">Control Panel</td>

      </tr>

      <tr>

        <td width="100%" class="leftbtnp">

        <a class="leftbtn lefthome" style="text-decoration: none" href="?a=account">My 

        Account</a></td>

      </tr>

      <tr>

        <td width="100%" class="leftbtnp">

        <a class="leftdep leftbtn" href="?a=deposit" style="text-decoration: none">Make Invest</a></td>

      </tr>

      <tr>

        <td width="100%" class="leftbtnp">

        <a class="leftlist leftbtn" href="?a=deposit_list" style="text-decoration: none">My Investments</a></td>

      </tr>

        <td width="100%" class="leftbtnp">

        <a class="leftlist leftbtn" href="?a=exchange" style="text-decoration: none">Exchange Service</a></td>

      </tr>

      <tr>

        <td width="100%" class="leftbtnp">

        <a class="leftwd leftbtn" href="?a=withdraw" style="text-decoration: none">Withdraw Funds</a></td>

      </tr>

      <tr>

        <td width="100%" class="leftbtnp">

        <a class="lefthis leftbtn" href="?a=earnings" style="text-decoration: none">My Transactions</a></td>

      </tr>

      <tr>

        <td width="100%" class="leftbtnp">

        <a class="leftref leftbtn" href="?a=referals" style="text-decoration: none">My Referral</a></td>

      </tr>

      <tr>

        <td width="100%" class="leftbtnp">

        <a class="leftrefl leftbtn" href="?a=referallinks" style="text-decoration: none">Promotional Banners</a></td>

              </tr>

              <tr>

        <td width="100%" class="leftbtnp">

        <a class="leftrefl leftbtn" href="?a=security" style="text-decoration: none">Security Center</a></td>

        

      </tr>

    </table>

    </td>

  </tr>

</table>

<br>

<div class="leftmenu">Certificate</div>

<br>

<div><a href="company/certificate.pdf" target="new"><img src="images/certificates.png" width="215" height="304" alt=""/></a></div>
</td>
    <td width="1000" valign="top"><?php }
}
?>