<?php /* Smarty version 3.1.27, created on 2018-05-12 04:21:30
         compiled from "/home/demozwni/hyips.demoscripts.website/tmpl/rules.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:14682230885af6a40a9baac1_10305943%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e74fd8acaf1052e8db729d317ff74ff961550bb6' => 
    array (
      0 => '/home/demozwni/hyips.demoscripts.website/tmpl/rules.tpl',
      1 => 1096538400,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '14682230885af6a40a9baac1_10305943',
  'variables' => 
  array (
    'site_name' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5af6a40aa31f97_48390913',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5af6a40aa31f97_48390913')) {
function content_5af6a40aa31f97_48390913 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/demozwni/hyips.demoscripts.website/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '14682230885af6a40a9baac1_10305943';
echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

<h3>Rules & Agreements.</h3>
<br>

<p align=justify>

Please read the following rules carefully before signing in.<br><br>



You agree to be of legal age in your country to partake in this program, and in all the cases your minimal age must be 18 years.<br><br>

<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['site_name']->value);?>
 is not available to the general public and is opened only to the qualified members of <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['site_name']->value);?>
, the use of this site is restricted to our members and to individuals personally invited by them. Every deposit is considered to be a private transaction between the <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['site_name']->value);?>
 and its Member.<br><br>
	
As a private transaction, this program is exempt from the US Securities Act of 1933, the US Securities Exchange Act of 1934 and the US Investment Company Act of 1940 and all other rules, regulations and amendments thereof. We are not FDIC insured. We are not a licensed bank or a security firm.<br><br>
  You agree that all information, communications, materials coming from <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['site_name']->value);?>
 
  are unsolicited and must be kept private, confidential and protected from any 
  disclosure. Moreover, the information, communications and materials contained 
  herein are not to be regarded as an offer, nor a solicitation for investments 
  in any jurisdiction which deems non-public offers or solicitations unlawful, 
  nor to any person to whom it will be unlawful to make such offer or solicitation.<br>
  <br>

All the data giving by a member to <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['site_name']->value);?>
 will be only privately used and not disclosed to any third parties. <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['site_name']->value);?>
 is not responsible or liable for any loss of data.<br><br>
  You agree to hold all principals and members harmless of any liability. You 
  are investing at your own risk and you agree that a past performance is not 
  an explicit guarantee for the same future performance. You agree that all information, 
  communications and materials you will find on this site are intended to be regarded 
  as an informational and educational matter and not an investment advice.<br>
  <br>
  We reserve the right to change the rules, commissions and rates of the program 
  at any time and at our sole discretion without notice, especially in order to 
  respect the integrity and security of the members' interests. You agree that 
  it is your sole responsibility to review the current terms. <br>
  <br>

<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['site_name']->value);?>
 is not responsible or liable for any damages, losses and costs resulting from any violation of the conditions and terms and/or use of our website by a member. You guarantee to <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['site_name']->value);?>
 that you will not use this site in any illegal way and you agree to respect your local, national and international laws.<br><br>

Don't post bad vote on Public Forums and at Gold Rating Site without contacting the administrator of our program FIRST. Maybe there was a technical problem with your transaction, so please always CLEAR the thing with the administrator.<br><br>

We will not tolerate SPAM or any type of UCE in this program. SPAM violators will be immediately and permanently removed from the program.<br><br>

<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['site_name']->value);?>
 reserves the right to accept or decline any member for membership without explanation.<br><br>

If you do not agree with the above disclaimer, please do not go any further.



</p>
<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>