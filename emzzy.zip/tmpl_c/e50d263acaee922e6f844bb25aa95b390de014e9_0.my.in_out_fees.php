<?php /* Smarty version 3.1.27, created on 2017-10-07 09:14:19
         compiled from "my:in_out_fees" */ ?>
<?php
/*%%SmartyHeaderCode:173197842159d8d32b5e6ba8_72112986%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e50d263acaee922e6f844bb25aa95b390de014e9' => 
    array (
      0 => 'my:in_out_fees',
      1 => 1507382059,
      2 => 'my',
    ),
  ),
  'nocache_hash' => '173197842159d8d32b5e6ba8_72112986',
  'variables' => 
  array (
    'ecs' => 0,
    'ec' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_59d8d32b69f990_35979038',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_59d8d32b69f990_35979038')) {
function content_59d8d32b69f990_35979038 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/demozwni/hyips.demoscripts.website/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '173197842159d8d32b5e6ba8_72112986';
?>
 <form method=post name=in_out> <input type=hidden name=a value=in_out_fees> <input type=hidden name=action value=save> <b>Deposit/Withdraw Fees:</b><br><br>  <table cellspacing=0 cellpadding=0 border=0><tr><td valign=top> <table cellspacing=1 cellpadding=2 border=0> <tr> <th class=title rowspan=3>Payment Sysytem</th> <th class=title colspan=6>Deposit</th> <th class=title colspan=6>Withdraw</th> </tr> <tr> <th class=title colspan=4>Fee</th> <th class=title colspan=2>Amount</th> <th class=title colspan=4>Fee</th> <th class=title colspan=2>Amount</th> </tr> <tr> <th class=title>%</th> <th class=title>$</th> <th class=title>Min</th> <th class=title>Max</th> <th class=title>Min</th> <th class=title>Max</th> <th class=title>%</th> <th class=title>$</th> <th class=title>Min</th> <th class=title>Max</th> <th class=title>Min</th> <th class=title>Max</th> </tr> <?php
$_from = $_smarty_tpl->tpl_vars['ecs']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$_smarty_tpl->tpl_vars['ec'] = new Smarty_Variable;
$_smarty_tpl->tpl_vars['ec']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['ec']->value) {
$_smarty_tpl->tpl_vars['ec']->_loop = true;
$foreach_ec_Sav = $_smarty_tpl->tpl_vars['ec'];
?> <tr> <td><span style="<?php if ($_smarty_tpl->tpl_vars['ec']->value['status']) {?>font-weight:bold;<?php }?>"><?php echo smarty_modifier_myescape(htmlspecialchars($_smarty_tpl->tpl_vars['ec']->value['name'], ENT_QUOTES, 'UTF-8', true));?>
</span></td> <td><input type=text name="in_percent[<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ec']->value['id']);?>
]" class=inpts value="<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ec']->value['fees']['in_percent']);?>
" size=4></td> <td><input type=text name="in_add_amount[<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ec']->value['id']);?>
]" class=inpts value="<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ec']->value['fees']['in_add_amount']);?>
" size=4></td> <td><input type=text name="in_fee_min[<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ec']->value['id']);?>
]" class=inpts value="<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ec']->value['fees']['in_fee_min']);?>
" size=4></td> <td><input type=text name="in_fee_max[<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ec']->value['id']);?>
]" class=inpts value="<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ec']->value['fees']['in_fee_max']);?>
" size=4></td> <td><input type=text name="in_amount_min[<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ec']->value['id']);?>
]" class=inpts value="<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ec']->value['fees']['in_amount_min']);?>
" size=4></td> <td><input type=text name="in_amount_max[<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ec']->value['id']);?>
]" class=inpts value="<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ec']->value['fees']['in_amount_max']);?>
" size=4></td> <td><input type=text name="out_percent[<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ec']->value['id']);?>
]" class=inpts value="<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ec']->value['fees']['out_percent']);?>
" size=4></td> <td><input type=text name="out_add_amount[<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ec']->value['id']);?>
]" class=inpts value="<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ec']->value['fees']['out_add_amount']);?>
" size=4></td> <td><input type=text name="out_fee_min[<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ec']->value['id']);?>
]" class=inpts value="<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ec']->value['fees']['out_fee_min']);?>
" size=4></td> <td><input type=text name="out_fee_max[<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ec']->value['id']);?>
]" class=inpts value="<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ec']->value['fees']['out_fee_max']);?>
" size=4></td> <td><input type=text name="out_amount_min[<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ec']->value['id']);?>
]" class=inpts value="<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ec']->value['fees']['out_amount_min']);?>
" size=4></td> <td><input type=text name="out_amount_max[<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ec']->value['id']);?>
]" class=inpts value="<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ec']->value['fees']['out_amount_max']);?>
" size=4></td> </tr> <?php
$_smarty_tpl->tpl_vars['ec'] = $foreach_ec_Sav;
}
?> </table> </td></tr></table> <br> <input type=submit value="Update" class=sbmt> </form> <br><br> <?php echo $_smarty_tpl->getSubTemplate ("my:start_info_table", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>
 In/Out Fees:<br> <br> Figures are the percents of an deposit and withdrawal.<br> <br> Fee:<br> % - percent of amount that will be holded from account.<br> $ - fee that will be added to percentage fee.<br> Min - fee that will be holded if percentage amount less then this value.<br> Max - fee that will be holded if percentage amount more then this value. Set Max to 0 to skip this limitation.<br> <br> Amount:<br> Min - minimal deposit/withdraw amount.<br> Max - maximal deposit/withdraw amount. Set Max to 0 to skip this limitation.<br> <br> To disable an particular operation set its percentage to 100. <?php echo $_smarty_tpl->getSubTemplate ("my:end_info_table", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>
 <?php }
}
?>