<?php /* Smarty version 3.1.27, created on 2018-05-14 15:17:47
         compiled from "/home/demozwni/hyips.demoscripts.website/tmpl/account_main.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:15414872415af9e0db9f91b4_66811177%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '14eac92826bfea750ac9c3c9ca600006d63ce2d5' => 
    array (
      0 => '/home/demozwni/hyips.demoscripts.website/tmpl/account_main.tpl',
      1 => 1455755120,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '15414872415af9e0db9f91b4_66811177',
  'variables' => 
  array (
    'userinfo' => 0,
    'last_access' => 0,
    'currency_sign' => 0,
    'ab_formated' => 0,
    'last_deposit' => 0,
    'last_withdrawal' => 0,
    'last_deposit_date' => 0,
    'last_withdrawal_date' => 0,
    'settings' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5af9e0dba1d449_92727525',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5af9e0dba1d449_92727525')) {
function content_5af9e0dba1d449_92727525 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/demozwni/hyips.demoscripts.website/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '15414872415af9e0db9f91b4_66811177';
echo $_smarty_tpl->getSubTemplate ("mheader.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%">
      <tr>
        <td width="100%" class="accnuser"><span  class="accuser">Username:</span> <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['userinfo']->value['username']);?>
 | <span  class="accreg">Registration Date:</span> <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['userinfo']->value['create_account_date']);?>
 
          | <span  class="acclog">Last  access:</span> <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['last_access']->value);?>
</td>
      </tr>
    </table>
<br>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%">
  <tr>
    <td width="100%" class="accbalance">
    Account Balance & Earning info
    </td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0">
  <tbody>
    <tr>
      <td width="51%" class="accpa">Total Account Balance: <span class="accbtxt"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);?>
<b><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ab_formated']->value['total']);?>
</b></span></td>
      <td width="49%" class="accpa">Total Earnings: <span class="accbtxt"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);?>
<b><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ab_formated']->value['earning']);?>
</b></span></td>
    </tr>
  </tbody>
</table>

<br>
<table width="100%" border="0" cellspacing="0">
  <tbody>
    <tr>
      <td class="accname">Deposits & Withdrawals Summary</td>
    </tr>
  </tbody>
</table>

<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%">
  <tr>
    <td class="acctit" colspan="2">
      <p align="left"></td>
    <td width="1%" class="acctit">&nbsp;</td>
    <td class="acctit" colspan="2">
      <p align="left"></td>
  </tr>
  <tr>
    <td width="24%" class="accbg1">Total Funds Invested:</td>
    <td width="25%" class="accbg2"><b><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);?>
<b><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ab_formated']->value['deposit']);?>
</b></b></td>
    <td width="1%" valign="top" rowspan="3">&nbsp;</td>
    <td width="23%" class="accbg1">Total  Withdrawn:</td>
    <td width="27%" class="accbg2"><b><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);?>
<b><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ab_formated']->value['withdrawal']);?>
</b></b></td>
  </tr>
  <tr>
    <td width="24%" class="accbg1">Last Investment:</td>
    <td width="25%" class="accbg2"><b><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);?>
<b><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['last_deposit']->value);?>
</b></b></td>
    <td width="23%" class="accbg1">Last Withdrawal:</td>
    <td width="27%" class="accbg2"><b><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);?>
<b><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['last_withdrawal']->value);?>
</b></b></td>
  </tr>
  <tr>
    <td width="24%" class="accbg1">Last Investment Date:</td>
    <td width="25%" class="accbg2"><b><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['last_deposit_date']->value);?>
</b></td>
    <td width="23%" class="accbg1">Last Withdrawal Date:</td>
    <td width="27%" class="accbg2"><b><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['last_withdrawal_date']->value);?>
</b></td>
  </tr>
</table>
<br>


<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%">
  <tr>
    <td width="100%" class="accref">Personal Referral Link:    </td>
  </tr>
</table>
<br>
<div class="acclink"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_url']);?>
/?ref=<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['userinfo']->value['username']);?>
</div>
<br>

<img src="https://bitcoincharts.com/charts/chart.png?width=970&m=bitstampUSD&SubmitButton=Draw&r=60&i=&c=0&s=&e=&Prev=&Next=&t=S&b=&a1=&m1=10&a2=&m2=25&x=0&i1=&i2=&i3=&i4=&v=1&cv=0&ps=0&l=0&p=0&" alt="Gold Chart"/>
<?php echo $_smarty_tpl->getSubTemplate ("mfooter.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>