<?php /* Smarty version 3.1.27, created on 2018-05-18 12:59:14
         compiled from "/home/ethgrhjj/investbiliecoin.club/tmpl/support.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:2389772635aff0662087587_09226667%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4dac047120e2399f5c5b643ec27967e65594ad64' => 
    array (
      0 => '/home/ethgrhjj/investbiliecoin.club/tmpl/support.tpl',
      1 => 1455776336,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2389772635aff0662087587_09226667',
  'variables' => 
  array (
    'settings' => 0,
    'say' => 0,
    'userinfo' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5aff06620cdea8_93930303',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5aff06620cdea8_93930303')) {
function content_5aff06620cdea8_93930303 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/ethgrhjj/investbiliecoin.club/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '2389772635aff0662087587_09226667';
echo $_smarty_tpl->getSubTemplate ("logo.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>



<div class="dirsupport"><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2483.6160680181283!2d-0.4311208846918689!3d51.50191261892608!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x487672636efffd4f%3A0x7f761dcb98d88bb3!2sHyde+Park+Hayes!5e0!3m2!1sen!2sir!4v1453995138611" frameborder="0" width="100%" height="300" marginwidth="0" marginheight="0" scrolling="no"></iframe></div>

<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="1349">

  <tr>

    <td width="100%" class="directory"><center>

    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="1200">

      <tr>

        <td width="100%">        

        <div class="dirurl"><a class="dirlink" href="index?a=home">home</a> / Contact us</div>

        </td>

      </tr>

    </table>

    </td>

  </tr>

</table>

<br>



<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="1200" height="41">

  <tr>

    <td width="470" valign="top" class="supportp" height="280">

    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber1" height="263">

      <tr>

        <td height="26" colspan="2" valign="top">

        <img border="0" src="images/contact.jpg" class="supportimg"></td>

        <td width="4%" height="26" valign="top">&nbsp;

        </td>

      </tr>

      <tr>

        <td height="19" colspan="2" valign="top">&nbsp;</td>

        <td width="4%" height="19" valign="top">&nbsp;</td>

      </tr>

      <tr>

        <td height="21" colspan="2" valign="middle" class="supporttit">Office Information:</td>

        <td height="21" valign="top">&nbsp;</td>

      </tr>

      <tr>

        <td width="7%" height="21" valign="middle" class="supportborder"><img src="images/clocation.png" width="30" height="30" alt=""/></td>

        <td width="89%" valign="middle" class="supportborder"><strong>Address: </strong><br>5th Floor, Hyde Park Hayes 3, 11 Millington Road, Hayes, UB3 4AZ</td>

        <td width="4%" height="21" valign="top">&nbsp;

        </td>

      </tr>

      <tr>

        <td width="7%" height="21" valign="middle" class="supportborder"><img src="images/cphone.png" width="30" height="30" alt=""/></td>

        <td width="89%" height="21" valign="middle" class="supportborder"><strong>Phone</strong>: +44 20 8144 4065</td>

        <td width="4%" height="21" valign="top">&nbsp;</td>

      </tr>

      <tr>

        <td height="21" colspan="2" valign="middle" class="">&nbsp;</td>

        <td height="21" valign="top">&nbsp;</td>

      </tr>

      <tr>

        <td height="21" colspan="2" valign="middle" class="supporttit">E-mails:</td>

        <td height="21" valign="top">&nbsp;</td>

      </tr>

      <tr>

        <td height="21" valign="middle" class="supportborder"><img src="images/cemail.png" width="30" height="30" alt=""/></td>

        <td height="21" valign="middle" class="supportborder"><strong>General:</strong> <a href="mailto:support@<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
">support@<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
</a></td>

        <td height="21" valign="top">&nbsp;</td>

      </tr>

      <tr>

        <td width="7%" height="21" valign="middle" class="supportborder"><img src="images/cemail.png" width="30" height="30" alt=""/></td>

        <td width="89%" height="21" valign="middle" class="supportborder"><strong>Payments:</strong> <a href="mailto:transactions@<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
">transactions@<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
</a></td>

        <td width="4%" height="21" valign="top">&nbsp;

          </td>

      </tr>

      <tr>

        <td width="7%" height="21" valign="middle" class="supportborder"><img src="images/cemail.png" width="30" height="30" alt=""/></td>

        <td width="89%" height="21" valign="middle" class="supportborder"><strong>Partners:</strong> <a href="mailto:partners@<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
">partners@<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
</a></td>

        <td width="4%" height="21" valign="top">&nbsp;</td>

      </tr>

      <tr>

        <td height="50" colspan="2" valign="top">&nbsp;</td>

        <td width="4%" height="50" valign="top">&nbsp;</td>

      </tr>

    </table>

    </td>

    <td width="755" valign="top" height="280">


<?php if ($_smarty_tpl->tpl_vars['say']->value == 'send') {?>
Message has been successfully sent. We will back to you in next 24 hours. Thank you.<br><br>
<?php } else { ?>

<?php echo '<script'; ?>
 language=javascript>
<?php if ($_smarty_tpl->tpl_vars['userinfo']->value['logged'] == 1) {?>

function checkform() { 
  if (document.mainform.message.value == '') {
    alert("Please type your message!");
    document.mainform.message.focus();
    return false;
  }
  return true;
}

<?php } else { ?>

function checkform() {
  if (document.mainform.name.value == '') {
    alert("Please type your full name!");
    document.mainform.name.focus();
    return false;
  }
  if (document.mainform.email.value == '') {
    alert("Please enter your e-mail address!");
    document.mainform.email.focus();
    return false;
  }
  if (document.mainform.message.value == '') {
    alert("Please type your message!");
    document.mainform.message.focus();
    return false;
  }
  return true;
}

<?php }?>
<?php echo '</script'; ?>
>

<?php echo '<script'; ?>
>

    function clearText(theField)
    {

    if (theField.defaultValue == theField.value)

    theField.value = '';

    }



    function addText(theField)

    {

    if (theField.value == '')

    theField.value = theField .defaultValue;

    }

              <?php echo '</script'; ?>
>



<form method=post name=mainform onsubmit="return checkform()">

<input type=hidden name=a value=support>

<input type=hidden name=action value=send>

<input type=hidden name=follow value=''>

<input type=hidden name=follow_id value=''>

<strong style="font-size: 18px">If you have any questions, use the feedback form  and we will reply you soon : </strong><br>

<br>

<table cellspacing=0 cellpadding=2 border=0>

<tr>

 
 <td>

 <input type="text" name="name" onblur="addText(this);" onfocus="clearText(this)" size=30 class=inpts value="Name:"></td>


</tr>

<tr>

 
 <td>

 <input type="text" name="email" onblur="addText(this);" onfocus="clearText(this)" size=30 class=inpts value="E-mail:"></td>


</tr>



<tr>



 <td colspan=2>

 <textarea name=message class=message onblur="addText(this);" onfocus="clearText(this)" cols=45 rows=4>Message:</textarea>

</tr>


<tr>

  <td colspan="2"><input type=submit value="Send" class=sbmt></td>

</tr></table>



</form>
<?php }?>



</td>

  </tr>

</table>

<p>












</td>



  </tr>



</table>  



<br>



<center>


<?php echo $_smarty_tpl->getSubTemplate ("footer2.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>