<?php /* Smarty version 2.6.2, created on 2017-08-31 10:11:00
         compiled from footer_install.tpl */ ?>

              </td>
              </tr>
            </table>
            <!-- Main: END -->

              </td>
             </tr>
           </table>
		  </td>
		 </tr>
	   </table>
	 </td>
  </tr>



  <tr> 
    <td height="19" bgcolor="ff8d00"><div align="center" class="forCopyright">All Rights Reserved. <a href='http://www.goldcoders.com' class="forCopyright">HYIP Manager</a></div></td>
  </tr>
</table>
</center></body>
</html>