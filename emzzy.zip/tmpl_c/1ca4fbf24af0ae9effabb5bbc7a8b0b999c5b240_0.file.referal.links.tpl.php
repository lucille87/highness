<?php /* Smarty version 3.1.27, created on 2018-05-14 06:41:49
         compiled from "/home/demozwni/hyips.demoscripts.website/tmpl/referal.links.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:4379150795af967ed28aae2_93590318%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1ca4fbf24af0ae9effabb5bbc7a8b0b999c5b240' => 
    array (
      0 => '/home/demozwni/hyips.demoscripts.website/tmpl/referal.links.tpl',
      1 => 1455761018,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '4379150795af967ed28aae2_93590318',
  'variables' => 
  array (
    'settings' => 0,
    'userinfo' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5af967ed30aad7_79372260',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5af967ed30aad7_79372260')) {
function content_5af967ed30aad7_79372260 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/demozwni/hyips.demoscripts.website/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '4379150795af967ed28aae2_93590318';
echo $_smarty_tpl->getSubTemplate ("mheader.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>


    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%">
  <tr>
    <td width="100%" class="accref">Personal Referral Link:    </td>
  </tr>
</table>
<br>
<div class="acclink"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_url']);?>
/?ref=<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['userinfo']->value['username']);?>
</div>
<br>

<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%">
  <tr>
    <td width="100%" class="refborderdott">
    </td>
  </tr>
  
  <tr>
    <td width="100%" align="center" class="refborder refbg1 refbg2">
    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber5" height="66">
      <tr>
        <td width="100%" height="22" align="center">
        <img border="0" src="images/banner_125.gif"></td>
      </tr>
      <tr>
        <td width="100%" height="22" align="center">&nbsp;</td>
      </tr>
      <tr>
        <td width="100%" height="22" align="center">
        <textarea rows="2" name="S1" cols="20" class="refinpts"><a href="<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_url']);?>
/?ref=<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['userinfo']->value['username']);?>
"><img border="0" src="<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_url']);?>
/images/banner_125.gif" width="125" height="125"></a></textarea></td>
      </tr>
    </table>
    </td>
  </tr>
  
  <tr>
    <td width="100%" align="center" class="refborder refbg1 refbg2"><table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber5" height="66">
      <tr>
        <td width="100%" height="22" align="center">
        <img border="0" src="images/banner_468.gif"></td>
      </tr>
      <tr>
        <td width="100%" height="22" align="center">&nbsp;</td>
      </tr>
      <tr>
        <td width="100%" height="22" align="center">
        <textarea rows="2" name="S1" cols="20" class="refinpts"><a href="<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_url']);?>
/?ref=<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['userinfo']->value['username']);?>
"><img border="0" src="<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_url']);?>
/images/banner_468.gif" width="468" height="60"></a></textarea></td>
      </tr>
    </table></td>
  </tr>
  
  <tr>
    <td width="100%" align="center" class="refborder refbg1 refbg2"><table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber5" height="66">
      <tr>
        <td width="100%" height="22" align="center">
        <img border="0" src="images/banner_728.gif"></td>
      </tr>
      <tr>
        <td width="100%" height="22" align="center">&nbsp;</td>
      </tr>
      <tr>
        <td width="100%" height="22" align="center">
        <textarea rows="2" name="S1" cols="20" class="refinpts"><a href="<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_url']);?>
/?ref=<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['userinfo']->value['username']);?>
"><img border="0" src="<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_url']);?>
/images/banner_728.gif" width="728" height="90"></a></textarea></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td width="100%" align="center">&nbsp;</td>
  </tr>
</table>
<br>
<?php echo $_smarty_tpl->getSubTemplate ("mfooter.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

<?php }
}
?>