<?php /* Smarty version 3.1.27, created on 2018-05-18 17:15:25
         compiled from "/home/ethgrhjj/investbiliecoin.club/tmpl/footer2.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:14618473595aff426de9d156_18366449%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a3e0067e18f441dcb431ca1e1abe7ed246d21fce' => 
    array (
      0 => '/home/ethgrhjj/investbiliecoin.club/tmpl/footer2.tpl',
      1 => 1456729142,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '14618473595aff426de9d156_18366449',
  'variables' => 
  array (
    'news' => 0,
    'settings' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5aff426deb81a2_86898782',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5aff426deb81a2_86898782')) {
function content_5aff426deb81a2_86898782 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/ethgrhjj/investbiliecoin.club/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '14618473595aff426de9d156_18366449';
?>

<div class="homecalbg"><table width="1200" border="0" cellspacing="0" cellpadding="0">



  <tbody>



    <tr>



      <td valign="top"><span class="homecaltit">Calculate Your Profit</span><br><br>



      <table width="1200" border="0" cellspacing="0" cellpadding="0">



  <tbody>



    <tr>



      <td width="240"> 



      <input id="deposit"  type="text" name="fullname" value="Enter Amount" class="homecalintps" onclick="if(this.value=='Enter Amount'){this.value=''}" onblur="if(this.value==''){this.value='Enter Amount'}" />



      </td>



      <td width="240"><select name="percent" class="homecalintps"  id="percent" onchange="calcthis(1);">



                  <option value="perc1" selected="selected" class="hlist2">Entry Plan - 3% Daily for 42 Days</option>



                  <option value="perc2">Basic Plan - 4% daily for 37 Days</option>



                  <option value="perc3">Advance Plan - 5% Daily for 32 Days</option>



                  <option value="perc4">Expert  Plan - 6% Daily for 27 Days</option>



                  <option value="perc5">Quick Profit Plan - 110% After 5 Days</option>



                  <option value="perc6">Advance Profit Plan - 140% After 10 Days</option>







                </select></td>



      <td width="240">&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" value="CALCULATE" onclick="calcthis(2);" class="homecalbtn"></td>



      <td width="240"><div class="homecal">ROI: $<b id="inpvar2">0</b></div></td>



      <td width="240"><div class="homecal">PROFIT: %<b id="inpvar1">0</b></div></td>



    </tr>



  </tbody>



</table>







      </td>



    </tr>



  </tbody>



</table>



</div>











<div class="fpayment"><img src="images/footer.png" width="1200" height="50" alt=""/></div>



<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="1349">



  <tr>



    <td width="100%" class="homestats">



    <center>



    















<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="1349">



  <tr>



    <td width="100%" class="fbg" valign="top">



    <center>



    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="1200" height="86">



      <tr>



        <td height="86"><table width="100%" border="0" cellspacing="0">



          <tbody>



            <tr>



              <td width="15%" height="91" valign="top"><div class="ftit fpadding1 fpadding2">Navigation</div>



                <a class="flink" href="index.php?a=cust&page=about">Home</a><br>



                



                <a class="flink" href="index.php?a=login">Access Account</a><a class="flink" href="index.php?a=cust&page=about"></a><br>



                <a class="flink" href="index.php?a=signup">Register an Account</a><a class="flink" href="index.php?a=cust&page=about"></a><br>



                <a class="flink" href="index.php?a=cust&page=about">About Our Company</a></td>



              <td width="12%" valign="top"><div class="ftit fpadding1 fpadding2">Support</div>



                <a class="flink" href="index.php?a=support">Contact Us</a><br>



                <a class="flink" href="index.php?a=faq">F.A.Q</a><br>



                <a class="flink" href="index.php?a=news">Last News</a><br>



                <a class="flink" href="index.php?a=rules">Terms Of Use</a></td>



              <td width="34%" valign="top"><div class="ftit fpadding1 fpadding2">Last News</div>



               


          <table cellspacing=0 cellpadding=2 border=0 width=100<?php echo '%>';?>
<tr>
 <th colspan=2><img src=images/q.gif width=1 height=3></th>
</tr>

<?php if (isset($_smarty_tpl->tpl_vars['smarty']->value['section']['s'])) unset($_smarty_tpl->tpl_vars['smarty']->value['section']['s']);
$_smarty_tpl->tpl_vars['smarty']->value['section']['s']['name'] = 's';
$_smarty_tpl->tpl_vars['smarty']->value['section']['s']['loop'] = is_array($_loop=$_smarty_tpl->tpl_vars['news']->value) ? count($_loop) : max(0, (int) $_loop); unset($_loop);
$_smarty_tpl->tpl_vars['smarty']->value['section']['s']['show'] = true;
$_smarty_tpl->tpl_vars['smarty']->value['section']['s']['max'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['loop'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['s']['step'] = 1;
$_smarty_tpl->tpl_vars['smarty']->value['section']['s']['start'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['step'] > 0 ? 0 : $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['loop']-1;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['s']['show']) {
    $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['total'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['loop'];
    if ($_smarty_tpl->tpl_vars['smarty']->value['section']['s']['total'] == 0)
        $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['show'] = false;
} else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['total'] = 0;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['s']['show']):

            for ($_smarty_tpl->tpl_vars['smarty']->value['section']['s']['index'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['iteration'] = 1;
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['iteration'] <= $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['total'];
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['index'] += $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['step'], $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['iteration']++):
$_smarty_tpl->tpl_vars['smarty']->value['section']['s']['rownum'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['iteration'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['s']['index_prev'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['index'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['s']['index_next'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['index'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['s']['first']      = ($_smarty_tpl->tpl_vars['smarty']->value['section']['s']['iteration'] == 1);
$_smarty_tpl->tpl_vars['smarty']->value['section']['s']['last']       = ($_smarty_tpl->tpl_vars['smarty']->value['section']['s']['iteration'] == $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['total']);
?>
<tr>
 <td class="hnews"><p align=justify>
 <a class="hnewstit" href="?a=news#<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['news']->value[$_smarty_tpl->getVariable('smarty')->value['section']['s']['index']]['id']);?>
">
<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['news']->value[$_smarty_tpl->getVariable('smarty')->value['section']['s']['index']]['title']);?>
</a><br>
  <div class="hnewstext"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['news']->value[$_smarty_tpl->getVariable('smarty')->value['section']['s']['index']]['small_text']);?>
</div>
  <small><br><small class="newsdate">Posted on: <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['news']->value[$_smarty_tpl->getVariable('smarty')->value['section']['s']['index']]['d']);?>
</small></small><br></p>
 </td>
</tr>
<?php endfor; endif; ?>
<tr>
 <td>
 </td>
</tr>
</table>


      </td>



              <td width="39%" valign="top"><br>



                



                <img src="images/logo.png" width="285" height="69" alt=""/><br><br>



                <table width="100%" border="0" cellspacing="0">



                  <tbody>



    <tr>



      <td width="7%" valign="top"><img src="images/clocation.png" width="20" height="20" alt=""/></td>



      <td width="93%" class="fadd">        5th Floor, Hyde Park Hayes 3, 11 Millington Road, Hayes, UB3 4AZ</td>



    </tr>



    <tr>



      <td valign="top"><img src="images/cemail.png" width="20" height="20" alt=""/></td>



      <td class="fadd"><a href="mailto:support@<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
">support@<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
</a>  <br><br>      



        <div class="ficp"><a href="https://www.facebook.com/<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
/" target="new"><img src="images/fb.png" alt="" width="20" height="20" class="ficon" title="FACEBOOK"/></a> <a href="https://twitter.com/primeforexbiz" target="new"><img src="images/twitter.png" alt="" width="20" height="20" class="ficon" title="TWITTER"/></a> <a href="?a=news.php" target="new"><img src="images/rss.png" alt="" width="20" height="20" class="ficon" title="BLOG"/></a></div></td>



    </tr>



  </tbody>



</table>



</td>



              </tr>



            </tbody>



        </table></td>



        </tr>



    </table>



    </td>



  </tr>



</table>







</td>



  </tr>



</table>







<div class="footercp">© <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 2016. All rights reserved. 



Registered Company </div>



<a href="#" class="scrollup">Scroll</a>












</center></body>



</html>



<?php }
}
?>