<?php /* Smarty version 3.1.27, created on 2018-05-17 23:25:43
         compiled from "/home/demozwni/hyips.demoscripts.website/tmpl/login.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:7090038405afe47b7d48375_95639696%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3ffeed316abc456c0abf1d59136a4aeb2f3bd723' => 
    array (
      0 => '/home/demozwni/hyips.demoscripts.website/tmpl/login.tpl',
      1 => 1455760306,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '7090038405afe47b7d48375_95639696',
  'variables' => 
  array (
    'userinfo' => 0,
    'frm' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5afe47b7dc6367_92329326',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5afe47b7dc6367_92329326')) {
function content_5afe47b7dc6367_92329326 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/demozwni/hyips.demoscripts.website/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '7090038405afe47b7d48375_95639696';
echo $_smarty_tpl->getSubTemplate ("logo.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>





<?php echo '<script'; ?>
 language=javascript>
function checkform() {
  if (document.mainform.username.value=='') {
    alert("Please type your username!");
    document.mainform.username.focus();
    return false;
  }
  if (document.mainform.password.value=='') {
    alert("Please type your password!");
    document.mainform.password.focus();
    return false;
  }
  return true;
}
<?php echo '</script'; ?>
>




<div class="dirlogin dirtxt">Access your account area
  <p></p>
    <a class="dirbtn" href="index.php?a=signup">start earning today </a></div>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="1349">
  <tr>
    <td width="100%" class="directory"><center>
    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="1200">
      <tr>
        <td width="100%">        
        <div class="dirurl"><a class="dirlink" href="index?a=home">home</a> / Login</div>
        </td>
      </tr>
    </table>
    </td>
  </tr>
</table>


<div class="container2">

  <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%">
    
    <tr>
      <td class="forgotbg loginop" width="100%" valign="top"><div class="block1">
        <center><h3>Login to your account</h3><form method=post name=mainform onsubmit="return checkform()">
          <input type=hidden name=a value='do_login'>
          <input type=hidden name=follow value=''>
          <input type=hidden name=follow_id value=''>
          <table cellspacing=0 cellpadding=2 border=0>
            <tr>
              <td class="loginborder" colspan="2"><div class="loginhtxt">Username:</div>
                <input type=text name=username value='' class="logininpts" size=30></td>
              </tr><tr>
                <td class="loginborder" colspan="2"><div class="loginhtxt">Password:</div>
                <input type=password name=password value='' class="passinpts keyboardInput" size=30></td>
                </tr>
				<?php if ($_smarty_tpl->tpl_vars['userinfo']->value['validation_enabled'] == 1) {?>
<tr>
 <td class=menutxt><img src="?a=show_validation_image&<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['userinfo']->value['session_name']);?>
=<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['userinfo']->value['session_id']);?>
&rand=<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['userinfo']->value['rand']);?>
"></td>
 <td><input type=text name=validation_number class=inpts size=30></td>
</tr>
<?php }?>
                        <tr>
              <td class="loginborder" colspan="2"><br><input type=submit value="Login" class=loginsbmt> <br><a class="" style="text-decoration: none" href="?a=forgot_password">Forgot Password ?</a><br>I am not a member - <a class="" style="text-decoration: none" href="?a=signup">
                Create an Account</a>
                <br><br></td>
            </tr></table>
          </form>
                <br>
				<?php if ($_smarty_tpl->tpl_vars['frm']->value['say'] == 'invalid_login') {?>
				        <img src="images/alert10.png" width="64" height="64" alt=""/>
<div class="loginerror">
  <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%">
            <tr>
              
              <td class="loginerror2" width="100%">&nbsp;
              
              Incorrect username / password !</td>
              </tr>
          </table></div>
                <br><?php }?>
				
				</td>
      </tr>
  </table>
</div>


<br><br>











</td>



  </tr>



</table>  



<br>



<center>




<?php echo $_smarty_tpl->getSubTemplate ("footer2.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>