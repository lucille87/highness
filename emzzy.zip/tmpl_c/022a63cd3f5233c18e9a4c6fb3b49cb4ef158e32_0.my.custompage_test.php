<?php /* Smarty version 3.1.27, created on 2017-09-23 22:37:01
         compiled from "my:custompage_test" */ ?>
<?php
/*%%SmartyHeaderCode:172169779959c71a4d3af493_60818855%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '022a63cd3f5233c18e9a4c6fb3b49cb4ef158e32' => 
    array (
      0 => 'my:custompage_test',
      1 => 1506220621,
      2 => 'my',
    ),
  ),
  'nocache_hash' => '172169779959c71a4d3af493_60818855',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_59c71a4d3e9a77_34333664',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_59c71a4d3e9a77_34333664')) {
function content_59c71a4d3e9a77_34333664 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '172169779959c71a4d3af493_60818855';
?>
<p>test</p>
<?php }
}
?>