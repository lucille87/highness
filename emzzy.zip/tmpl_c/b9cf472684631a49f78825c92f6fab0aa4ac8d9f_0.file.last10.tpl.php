<?php /* Smarty version 3.1.27, created on 2018-05-18 02:06:10
         compiled from "/home/demozwni/hyips.demoscripts.website/tmpl/last10.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:14160605055afe6d52d2e696_88633928%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b9cf472684631a49f78825c92f6fab0aa4ac8d9f' => 
    array (
      0 => '/home/demozwni/hyips.demoscripts.website/tmpl/last10.tpl',
      1 => 1455766320,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '14160605055afe6d52d2e696_88633928',
  'variables' => 
  array (
    'settings' => 0,
    'top' => 0,
    'currency_sign' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5afe6d52d49d09_31149531',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5afe6d52d49d09_31149531')) {
function content_5afe6d52d49d09_31149531 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/demozwni/hyips.demoscripts.website/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '14160605055afe6d52d2e696_88633928';
?>
<html>



<head>



<meta http-equiv="Content-Language" content="en-us">







<title><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
</title>



<?php echo '<script'; ?>
 type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"><?php echo '</script'; ?>
>



<?php echo '<script'; ?>
 type="text/javascript" src="js/jquery.easing.1.3.js"><?php echo '</script'; ?>
>







<?php echo '<script'; ?>
 type="text/javascript" src="js/video.js"><?php echo '</script'; ?>
>







<?php echo '<script'; ?>
 type="text/javascript" src="js/script.js"><?php echo '</script'; ?>
>







<?php echo '<script'; ?>
 type="text/javascript" src="js/calc.js"><?php echo '</script'; ?>
>



<?php echo '<script'; ?>
 src="js/r.js" type="text/javascript"><?php echo '</script'; ?>
>



<link href="style.css" rel="stylesheet" type="text/css">



<link href="tabcontent.css" rel="stylesheet" type="text/css">



<?php echo '<script'; ?>
 type="text/javascript" src="js/tabcontent.js"><?php echo '</script'; ?>
>



<link rel="icon" href="images/icon.ico" type="image/x-icon">



<?php echo '<script'; ?>
 type="text/javascript" src="js/keyboard.js" charset="UTF-8"><?php echo '</script'; ?>
>



<link rel="stylesheet" type="text/css" href="keyboard.css">



<?php echo '<script'; ?>
 type="text/javascript" src="js/tinybox.js"><?php echo '</script'; ?>
>



<?php echo '<script'; ?>
 src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"><?php echo '</script'; ?>
>





<?php echo '<script'; ?>
 src="js/easySlider1.7.js"><?php echo '</script'; ?>
>



</head>



<body topmargin="0">
<table cellspacing=0 cellpadding=2 border=0 width=100<?php echo '%>';?>





<?php if ($_smarty_tpl->tpl_vars['top']->value) {?>
<?php if (isset($_smarty_tpl->tpl_vars['smarty']->value['section']['s'])) unset($_smarty_tpl->tpl_vars['smarty']->value['section']['s']);
$_smarty_tpl->tpl_vars['smarty']->value['section']['s']['name'] = 's';
$_smarty_tpl->tpl_vars['smarty']->value['section']['s']['loop'] = is_array($_loop=$_smarty_tpl->tpl_vars['top']->value) ? count($_loop) : max(0, (int) $_loop); unset($_loop);
$_smarty_tpl->tpl_vars['smarty']->value['section']['s']['show'] = true;
$_smarty_tpl->tpl_vars['smarty']->value['section']['s']['max'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['loop'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['s']['step'] = 1;
$_smarty_tpl->tpl_vars['smarty']->value['section']['s']['start'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['step'] > 0 ? 0 : $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['loop']-1;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['s']['show']) {
    $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['total'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['loop'];
    if ($_smarty_tpl->tpl_vars['smarty']->value['section']['s']['total'] == 0)
        $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['show'] = false;
} else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['total'] = 0;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['s']['show']):

            for ($_smarty_tpl->tpl_vars['smarty']->value['section']['s']['index'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['iteration'] = 1;
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['iteration'] <= $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['total'];
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['index'] += $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['step'], $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['iteration']++):
$_smarty_tpl->tpl_vars['smarty']->value['section']['s']['rownum'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['iteration'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['s']['index_prev'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['index'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['s']['index_next'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['index'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['s']['first']      = ($_smarty_tpl->tpl_vars['smarty']->value['section']['s']['iteration'] == 1);
$_smarty_tpl->tpl_vars['smarty']->value['section']['s']['last']       = ($_smarty_tpl->tpl_vars['smarty']->value['section']['s']['iteration'] == $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['total']);
?>
<tr>



 <td class="lastbr"><img src=images/<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['top']->value[$_smarty_tpl->getVariable('smarty')->value['section']['s']['index']]['ec']);?>
.gif></td>



 <td class="lastbr"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);
echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['top']->value[$_smarty_tpl->getVariable('smarty')->value['section']['s']['index']]['balance']);?>
</td>



 <td class="lastbr"></td>



 <td class="lastbr"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['top']->value[$_smarty_tpl->getVariable('smarty')->value['section']['s']['index']]['username']);?>
</td>



 </td>



</tr>
<?php endfor; endif; ?>
<?php } else { ?>





<tr>



 <td class="lastbr"></td>



 <td class="lastbr">N/A</td>



 <td class="lastbr"></td>



 <td class="lastbr">No investors found</td>



 </td>



</tr>
<?php }?>




</table>

</body>



</html>



<?php }
}
?>