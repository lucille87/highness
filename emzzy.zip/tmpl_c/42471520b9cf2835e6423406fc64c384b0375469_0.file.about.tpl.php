<?php /* Smarty version 3.1.27, created on 2018-05-17 23:26:01
         compiled from "/home/demozwni/hyips.demoscripts.website/tmpl/custom/about.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:1568436955afe47c9756ca3_75385123%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '42471520b9cf2835e6423406fc64c384b0375469' => 
    array (
      0 => '/home/demozwni/hyips.demoscripts.website/tmpl/custom/about.tpl',
      1 => 1506220621,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1568436955afe47c9756ca3_75385123',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5afe47c976bea8_08791486',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5afe47c976bea8_08791486')) {
function content_5afe47c976bea8_08791486 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '1568436955afe47c9756ca3_75385123';
$_smarty_tpl->tpl_vars["allow"] = new Smarty_Variable("all", null, 0);?>
<?php $_smarty_tpl->tpl_vars["meta_title"] = new Smarty_Variable('', null, 0);?>
<?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

<p>test</p>

<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>