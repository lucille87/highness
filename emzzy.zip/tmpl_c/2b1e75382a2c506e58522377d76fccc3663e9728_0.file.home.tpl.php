<?php /* Smarty version 3.1.27, created on 2018-05-18 17:15:25
         compiled from "/home/ethgrhjj/investbiliecoin.club/tmpl/home.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:18448057105aff426de61e37_66004742%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2b1e75382a2c506e58522377d76fccc3663e9728' => 
    array (
      0 => '/home/ethgrhjj/investbiliecoin.club/tmpl/home.tpl',
      1 => 1526647785,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '18448057105aff426de61e37_66004742',
  'variables' => 
  array (
    'settings' => 0,
    'currency_sign' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5aff426de94472_46234087',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5aff426de94472_46234087')) {
function content_5aff426de94472_46234087 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/ethgrhjj/investbiliecoin.club/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '18448057105aff426de61e37_66004742';
?>
<html>



<head>



<meta http-equiv="Content-Language" content="en-us">







<title><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
</title>



<?php echo '<script'; ?>
 type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"><?php echo '</script'; ?>
>



<?php echo '<script'; ?>
 type="text/javascript" src="js/jquery.easing.1.3.js"><?php echo '</script'; ?>
>







<?php echo '<script'; ?>
 type="text/javascript" src="js/video.js"><?php echo '</script'; ?>
>







<?php echo '<script'; ?>
 type="text/javascript" src="js/script.js"><?php echo '</script'; ?>
>







<?php echo '<script'; ?>
 type="text/javascript" src="js/calc.js"><?php echo '</script'; ?>
>



<?php echo '<script'; ?>
 src="js/r.js" type="text/javascript"><?php echo '</script'; ?>
>



<link href="style.css" rel="stylesheet" type="text/css">



<link href="tabcontent.css" rel="stylesheet" type="text/css">



<?php echo '<script'; ?>
 type="text/javascript" src="js/tabcontent.js"><?php echo '</script'; ?>
>



<link rel="icon" href="images/icon.ico" type="image/x-icon">



<?php echo '<script'; ?>
 type="text/javascript" src="js/keyboard.js" charset="UTF-8"><?php echo '</script'; ?>
>



<link rel="stylesheet" type="text/css" href="keyboard.css">



<?php echo '<script'; ?>
 type="text/javascript" src="js/tinybox.js"><?php echo '</script'; ?>
>



<?php echo '<script'; ?>
 src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"><?php echo '</script'; ?>
>







<?php echo '<script'; ?>
 type="text/javascript">



  $(document).ready(function () {







      $(window).scroll(function () {



          if ($(this).scrollTop() > 100) {



              $('.scrollup').fadeIn();



          } else {



              $('.scrollup').fadeOut();



          }



      });







      $('.scrollup').click(function () {



          $("html, body").animate({



              scrollTop: 0



          }, 600);



          return false;



      });







  });



<?php echo '</script'; ?>
>















<?php echo '<script'; ?>
 src="js/easySlider1.7.js"><?php echo '</script'; ?>
>







<?php echo '<script'; ?>
>



$(document).ready(function(){



   $("#slider").easySlider({



      auto: true,



      continuous: true,



	  numeric: true



   });



});



<?php echo '</script'; ?>
>







</head>



<body class="bodybg" topmargin="0">







<center>











<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="1349" id="AutoNumber1">



  <tr>



    <td width="100%" class="logotdbg">







<div class="logomenu">



<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="1349">



  <tr>



    <td width="100%">



    <center>



    <table width="1200" border="0" cellspacing="0">



  <tbody>



    <tr>



      <td width="196" height="86"><a href="?a=home"><img src="images/logo.png"  alt=""/></a></td>



      <td width="691" align="center" class="logotxtc"><span class="logophone"> <a class="logosupport" href="skype:<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
?call">SKYPE: <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
</a></span><span id="online" class="homeusers"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['info_box_visitor_online_generated']);?>
</span> <span class="homeusers2">Online users</span><span id="acc" class="homeusers"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['info_box_total_accounts_generated']);?>
</span> <span class="homeusers2">Total investors</span></td>



      <td width="230" align="right"><a href="?a=signup" class="logodate">Sign up</a>



         <a class="logologin" style="text-decoration: none" href="?a=login">Login</a>



        </td>



    </tr>



  </tbody>



</table>



<div class="logomenubg">



    <div class="logomenubp"><UL id="menu"><li><a class="current" href="?a=home">Home</a></li><li><a href="?a=signup">Sign up</a></li><li><a href="?a=login">Login</a></li>



   






<li><a href='?a=news'>News</a></li>



<li><a href='?a=cust&page=about'>about Our Company</a></li>



<li><a href='?a=cust&page=privacy'>PRIVACY POLICY</a></li>


<li><a href='?a=cust&page=chat'>Shoutbox</a></li>


<li><a href='?a=faq'>F.A.Q</a></li>



<li><a href='?a=rules'>terms of use</a></li>



<li><a href='http://www.allhyipmonitors.com/search/?keyword=<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
' target='new'>Rate us</a></li>



<li><a href='?a=support'>contact us</a></li>



</ul></div></div></td>



  </tr>



</table>



</div>



<div class="page-wrap1"></div>



<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="1349">







<iframe src="slider2/index.html" frameborder="0" width="100%" height="520" marginwidth="0" marginheight="0" scrolling="no"></iframe>  



</table>



<div class="logosign">



<center>



<table width="1200" border="0" cellspacing="0">



  <tbody>



    <tr>



      <td class="logop logotxt" width="961">Important:  Always check the "Green Status Bar".</td>



      <td width="235" style="text-align: right"><img src="images/evis.png" width="385" height="30" alt=""/></td>



    </tr>



  </tbody>



</table>



</div>



<center>







<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="1200">



  <tr>



    <td width="100%"><center>



    





            
<div class="psh">






<br><br><br><br>







<table width="1200" border="0" cellspacing="0">



  <tbody>



    <tr valign="top">



      <td width="406"><img src="images/page1-img2.jpg" width="370" height="240" alt=""/></td>



      <td width="790"><div class="homeabout">WHO WE ARE</div><br>



      <div class="homeabouttxt"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 is a U.K. based company, We've spent the past three years trying to make PrimeForex LIMITED into one of the most advanced companies in the field of Forex Trading.



Our Company succeeded to support multiple Trading instruments (futures, forex, stocks, and options).



<br><br>



Our advanced trading robots made by our in house programming team, Our in house backtesting and strategy developer focus on dynamic trading environment. Our State of the Art AutoTrade bot technology (ATBT)  is one of our most powerful trading robot for automated trading.<br><br>



<a class="sbmt" href="index.php?a=cust&page=about">More About us</a></div></td>



    </tr>



  </tbody>



</table>



















<br><br><br><br>



<div class="homeboldtxt">



  <table width="1200" border="0" cellspacing="0" cellpadding="0">



    <tbody>



      <tr>



        <td>



        <div class="homeplans">investment plans</div>



<div class="slider-container">



  <div id="slider">



    <ul>



    <li>



    <div class="slide">



     <table width="100%" border="0" cellspacing="0" cellpadding="0">



  <tbody>



    <tr>



      <td class="planpad"><div class="planbox">



      <span class="planrate">Entry Plan</span>



      <span class="plandate">13% After 12 Hours</span>


      <span class="plantxt">Principal: Return</span>


      <span class="plantxt">minimum: $250</span>



      <span class="plantxt">maximum: $10000</span>



      <br>



      <a class="sbmt" href="?a=signup">invest now </a><br><br></div></td>



      <td class="planpad"><div class="planbox">



      <span class="planrate">Basic Plan</span>



      <span class="plandate">30% After 4 hours</span>


      <span class="plantxt">Principal: Return</span>


      <span class="plantxt">minimum: $500</span>



      <span class="plantxt">maximum: $330000</span>



      <br>



      <a class="sbmt" href="?a=signup">invest now </a><br><br></div></td>



      <td><div class="planbox">



      <span class="planrate">Advance Plan</span>



      <span class="plandate">200% After 24 hours</span>


      <span class="plantxt">Principal: Return</span>


      <span class="plantxt">minimum: $5000</span>



      <span class="plantxt">maximum: $5500000</span>



      <br>



      <a class="sbmt" href="?a=signup">invest now </a><br><br></div></td>



    </tr>



  </tbody>



</table>











    </div>



    </li>



    



    <li>



    <div class="slide">



<table width="100%" border="0" cellspacing="0" cellpadding="0">



  <tbody>



    <tr>



      <td class="planpad"><div class="planbox">



      <span class="planrate">Entry Plan</span>



      <span class="plandate">13% After 12 Hours</span>


      <span class="plantxt">Principal: Return</span>


      <span class="plantxt">minimum: $250</span>



      <span class="plantxt">maximum: $10000</span>



      <br>



      <a class="sbmt" href="?a=signup">invest now </a><br><br></div></td>



      <td class="planpad"><div class="planbox">



      <span class="planrate">Basic Plan</span>



      <span class="plandate">30% after 4 hours</span>


      <span class="plantxt">Principal: Return</span>


      <span class="plantxt">minimum: $500</span>



      <span class="plantxt">maximum: $330000</span>



      <br>



      <a class="sbmt" href="?a=signup">invest now </a><br><br></div></td>



      <td><div class="planbox">



      <span class="planrate">Advance Plan</span>



      <span class="plandate">200% After 24 hours</span>


      <span class="plantxt">Principal: Return</span>


      <span class="plantxt">minimum: $5000</span>



      <span class="plantxt">maximum: $5500000</span>



      <br>



      <a class="sbmt" href="?a=signup">invest now </a><br><br></div></td>



    </tr>



  </tbody>



</table>



    </div>



    </li>



    



    



    </ul>



    



   </div>



   



</div></td>



      </tr>



    </tbody>



  </table>



</div>







<img src="images/plbg.png" width="948" height="54" alt=""/><br>











<br>



















<br>







<div class="homebottom"><span class="homebottom2">10%</span> referral commission </div>











<br><br><br>







<div class="statsbg">



<table width="1200" border="0" cellspacing="0" cellpadding="0">



  <tbody>



    <tr>



      



      <td align="center"><div class="homestatbox"><img class="statimg" src="images/clock118.png" width="64" height="64" alt=""/><br><br>



        <span class="logostatam"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_days_online_generated']);?>
</span><br>



      <span class="logostattxt">running days</span></div></td>



      <td align="center"><div class="homestatbox"><img class="statimg" src="images/savings4.png" width="64" height="64" alt=""/><br><br>



        <span class="logostatam"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);?>
 <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['info_box_deposit_funds_generated']);?>
</span><br>



      <span class="logostattxt">total deposited</span></div></td>



      <td align="center"><div class="homestatbox"><img class="statimg" src="images/withdraw1(1).png" width="64" height="64" alt=""/><br><br>



        <span class="logostatam"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);?>
 <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['info_box_withdraw_funds_generated']);?>
</span><br>



      <span class="logostattxt">total withdraw</span></div></td>



    </tr>



  </tbody>



</table>



</div>







<br><br><br>







<table width="1200" border="0" cellspacing="0" cellpadding="0">



  <tbody>



    <tr>



      <td valign="top"><div class="homebtbr">



        <div class="homeadvantage">Last 10 DEPOSITS



</div><br>



  



  


<!-- Image Table: Start -->

<iframe frameborder=0 height=322 width=100% scrolling=no src='/?a=last10'></iframe>





 



      </div></td>



      <td valign="top"><div class="homebtbr">



        <div class="homeadvantage">last 10 WITHDRAWALS



</div><br>



        



  


<!-- Image Table: Start -->

<iframe frameborder=0 height=322 width=100% scrolling=no src='/?a=paidout'></iframe>







 



      </div></td>



      <td valign="top"><div class="homebtbr">



        <div class="homeadvantage">Our Advantages</div><br><table width="100%" border="0" cellspacing="0">



          <tbody>



            <tr valign="top">



              <td width="10%"><img src="images/adprotection.png" width="50" height="50" alt=""/></td>



              <td width="69%"><div class="homeadtit">Protection</div>



                <div class="homeadtxt">Dedicated Server with maximum DDos Protection</div></td>



              </tr>



            </tbody>



        </table>



        



  <table width="100%" border="0" cellspacing="0">



    <tbody>



      <tr valign="top">



        <td width="10%"><img src="images/adssl.png" width="50" height="50" alt=""/></td>



        <td width="69%"><div class="homeadtit">Encryption</div>



          <div class="homeadtxt">Highly secured 128bit SSL encryption</div></td>



        </tr>



      </tbody>



  </table>



        



  <table width="100%" border="0" cellspacing="0">



    <tbody>



      <tr valign="top">



        <td width="10%"><img src="images/adincome.png" width="50" height="50" alt=""/></td>



        <td width="69%"><div class="homeadtit">Stable Income</div>



          <div class="homeadtxt">Unique Investment Products</div></td>



        </tr>



      </tbody>



  </table>



        



  <table width="100%" border="0" cellspacing="0">



    <tbody>



      <tr valign="top">



        <td width="10%"><img src="images/adstaff.png" width="50" height="50" alt=""/></td>



        <td width="69%"><div class="homeadtit">Multiple Language Support</div>



          <div class="homeadtxt">24/7 Customer Support</div></td>



        </tr>



      </tbody>



  </table>



        



  <table width="100%" border="0" cellspacing="0">



    <tbody>



      <tr valign="top">



        <td width="10%"><img src="images/adfast.png" width="50" height="50" alt=""/></td>



        <td width="69%"><div class="homeadtit">Fast Payments</div>



          <div class="homeadtxt">



            Quick Process within 1 min*</div></td>



        </tr>



      </tbody>



  </table>



      </div></td>



    </tr>



  </tbody>



</table>











<br>































<br>






















</td>



  </tr>



</table>  



<br>



<center>






<?php echo $_smarty_tpl->getSubTemplate ("footer2.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>