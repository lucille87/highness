<?php /* Smarty version 3.1.27, created on 2018-05-18 05:09:35
         compiled from "my:editaccount_2" */ ?>
<?php
/*%%SmartyHeaderCode:5542765505afe984f998002_51966341%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3343014239e3e2b8908ea06697548cf733a73735' => 
    array (
      0 => 'my:editaccount_2',
      1 => 1526634575,
      2 => 'my',
    ),
  ),
  'nocache_hash' => '5542765505afe984f998002_51966341',
  'variables' => 
  array (
    'user' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5afe984f99bd09_40426456',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5afe984f99bd09_40426456')) {
function content_5afe984f99bd09_40426456 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/ethgrhjj/investbiliecoin.club/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '5542765505afe984f998002_51966341';
?>
 <tr> <td>E-mail address:</td> <td><input type=text name=email value="<?php echo smarty_modifier_myescape(htmlspecialchars($_smarty_tpl->tpl_vars['user']->value['email'], ENT_QUOTES, 'UTF-8', true));?>
" class=inpts size=30></td> </tr><?php }
}
?>