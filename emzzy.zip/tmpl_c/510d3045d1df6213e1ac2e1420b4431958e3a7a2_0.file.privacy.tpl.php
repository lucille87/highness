<?php /* Smarty version 3.1.27, created on 2018-05-14 06:36:33
         compiled from "/home/demozwni/hyips.demoscripts.website/tmpl/custom/privacy.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:12828023765af966b1ba9379_63856265%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '510d3045d1df6213e1ac2e1420b4431958e3a7a2' => 
    array (
      0 => '/home/demozwni/hyips.demoscripts.website/tmpl/custom/privacy.tpl',
      1 => 1455751586,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '12828023765af966b1ba9379_63856265',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5af966b1bb9b17_27349704',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5af966b1bb9b17_27349704')) {
function content_5af966b1bb9b17_27349704 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '12828023765af966b1ba9379_63856265';
echo $_smarty_tpl->getSubTemplate ("logo.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

<div class="dirprivacy dirtxt">We respect your right to privacy
  <p></p>
    <a class="dirbtn" href="index.php?a=signup">start earning today </a></div>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="1349">
  <tr>
    <td width="100%" class="directory"><center>
    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="1200">
      <tr>
        <td width="100%">        
        <div class="dirurl"><a class="dirlink" href="index?a=home">home</a> / Privacy policy</div>
        </td>
      </tr>
    </table>
    </td>
  </tr>
</table>
<br>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="1200">
  <tr>
    <td width="100%">
<p align=justify>



 Thank you for participating in our company, which is engaged in receiving of profits in the Forex market. Our company understands the importance of personal information of every participant. Cooperating with our company, you can be sure in privacy of your personal information and in its protection by our employees. Our employees protect the collected by them information from unauthorized access. We use a variety of technologies to reduce the risk of theft of accounts and receiving personal information of our investors.</p>
<div class="ruletit">Personal information&quot; includes such items as</div><br>
1. Name and Last Name of the investor <br>
2. Locations <br>
3. Personal account of electronic currency <br>
4. Login and password
<p>Our company collects your personal information only with your consent and confidence in the security of your personal information on our project. Users should note, that the collection of personal information is only from adult. The rules of our company explain, how your information is collected and used. These rules apply only in our website. Information which is collected when you visit this site.</p>
</p>
<div class="ruletit">Visiting our website, such information is automatically collected</div><br>
1. Your Internet Provider<br>
2. Your location and country of residence<br>
3. Your browser and type of operating system
<p>This types of information are also the part of the personal information.</p>
</p>
<div class="ruletit">Information Storage</div><br>
Saving of information is only in our company or its equipment. Personal information is stored in accordance with the rules of storage and disposal, which are set for archive of our company. To receive your personal information, contact direct with our employees.
<p>&nbsp;</p>
</p>
<div class="ruletit">Contact Information</div><br>
If you have questions about the storage of personal information on this site, contact us, please.
<p>&nbsp;</p>
</p>
</td>
  </tr>
</table>



</td>



  </tr>



</table>  



<br>



<center>






<?php echo $_smarty_tpl->getSubTemplate ("footer2.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>