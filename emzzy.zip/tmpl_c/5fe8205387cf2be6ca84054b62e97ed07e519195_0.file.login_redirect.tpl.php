<?php /* Smarty version 3.1.27, created on 2018-05-18 06:54:09
         compiled from "/home/ethgrhjj/investbiliecoin.club/tmpl/login_redirect.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:10128887655afeb0d13aedf7_71938066%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5fe8205387cf2be6ca84054b62e97ed07e519195' => 
    array (
      0 => '/home/ethgrhjj/investbiliecoin.club/tmpl/login_redirect.tpl',
      1 => 1455776812,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '10128887655afeb0d13aedf7_71938066',
  'variables' => 
  array (
    'userinfo' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5afeb0d13bdf29_81637437',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5afeb0d13bdf29_81637437')) {
function content_5afeb0d13bdf29_81637437 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/ethgrhjj/investbiliecoin.club/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '10128887655afeb0d13aedf7_71938066';
?>
<html>
<head>
<link href="styledirect.css" rel="stylesheet" type="text/css">
<link href="flaticon.css" rel="stylesheet" type="text/css">
<META HTTP-EQUIV=Refresh CONTENT="0; URL=?a=account">

</head>
<body>
<br><br><br><br><br><br><br><br>
<center>
<img border="0" src="images/logo.png">
<br><br>
<div class="bar1">Hello dear <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['userinfo']->value['username']);?>
<br>
Please wait , You are redirecting ...</div>
<br>
<a class="sbmt" href="?a=account">Account Area</a>


<br><br><br>
</center>
</body>
</html><?php }
}
?>