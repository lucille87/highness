<?php /* Smarty version 3.1.27, created on 2018-01-18 19:08:00
         compiled from "my:exp_deposits" */ ?>
<?php
/*%%SmartyHeaderCode:15582465195a6136e0d6a482_85458782%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '285a3abc85e2b9f84f8b4c07069e6fec1c460d93' => 
    array (
      0 => 'my:exp_deposits',
      1 => 1516320480,
      2 => 'my',
    ),
  ),
  'nocache_hash' => '15582465195a6136e0d6a482_85458782',
  'variables' => 
  array (
    'deposits' => 0,
    'd' => 0,
    'settings' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5a6136e0deeef6_30819960',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5a6136e0deeef6_30819960')) {
function content_5a6136e0deeef6_30819960 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/demozwni/hyips.demoscripts.website/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '15582465195a6136e0d6a482_85458782';
?>
 <b>Deposits:</b><br><br> <table cellpadding=1 cellspacing=1 border=0 width=100<?php echo '%>';?> <tr> <th bgcolor=FFEA00>User</th> <th bgcolor=FFEA00>Plan</th> <th bgcolor=FFEA00>Deposit</th> <th bgcolor=FFEA00>Expires</th> <th bgcolor=FFEA00>Action</th> </tr> <?php
$_from = $_smarty_tpl->tpl_vars['deposits']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$_smarty_tpl->tpl_vars['d'] = new Smarty_Variable;
$_smarty_tpl->tpl_vars['d']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['d']->value) {
$_smarty_tpl->tpl_vars['d']->_loop = true;
$foreach_d_Sav = $_smarty_tpl->tpl_vars['d'];
?> <tr> <td><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['d']->value['username']);?>
</td> <td><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['d']->value['plan_name']);?>
 (<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['d']->value['q_days']);?>
)</td> <td align=right nowrap><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['currency_sign']);
echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['d']->value['amount']);?>
 <img src="images/<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['d']->value['ec']);?>
.gif" height=17 align=absmiddle></td> <td align=right><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['d']->value['expire']);?>
</td> <td nowrap><a href="?a=editaccount&id=<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['d']->value['user_id']);?>
" target=_blank>[account]</a> <a href="?a=userfunds&id=<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['d']->value['user_id']);?>
" target=_blank>[funds]</a></td> </tr> <?php
$_smarty_tpl->tpl_vars['d'] = $foreach_d_Sav;
}
if (!$_smarty_tpl->tpl_vars['d']->_loop) {
?> <tr> <td align=center colspan=4>No records found</td> </tr> <?php
}
?> </table> <br>  <?php }
}
?>