<?php /* Smarty version 3.1.27, created on 2018-05-18 12:59:15
         compiled from "/home/ethgrhjj/investbiliecoin.club/tmpl/header.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:1130891125aff066307a520_23137889%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ee32f49c61ab38465fcbf03c82fbdd2145ca2649' => 
    array (
      0 => '/home/ethgrhjj/investbiliecoin.club/tmpl/header.tpl',
      1 => 1455749712,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1130891125aff066307a520_23137889',
  'variables' => 
  array (
    'settings' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5aff06630816e7_65088987',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5aff06630816e7_65088987')) {
function content_5aff06630816e7_65088987 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/ethgrhjj/investbiliecoin.club/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '1130891125aff066307a520_23137889';
echo $_smarty_tpl->getSubTemplate ("logo.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>


    <div class="dirfaq dirtxt"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>

    <p></p>

    <a class="dirbtn" href="index.php?a=signup">start earning today </a></div>

<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="1349">

  <tr>

    <td width="100%" class="directory"><center>

    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="1200">

      <tr>

        <td width="100%">        

        <div class="dirurl"><a class="dirlink" href="index?a=home">home</a> />></div>

        </td>

      </tr>

    </table>

    </td>

  </tr>

</table>

<br>

<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="1200">

  <tr>

    <td width="100%"><?php }
}
?>