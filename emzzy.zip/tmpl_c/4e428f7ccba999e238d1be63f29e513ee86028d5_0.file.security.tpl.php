<?php /* Smarty version 3.1.27, created on 2017-11-19 02:49:31
         compiled from "/home/demozwni/hyips.demoscripts.website/tmpl/security.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:13668229725a11378b4c3494_88090822%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4e428f7ccba999e238d1be63f29e513ee86028d5' => 
    array (
      0 => '/home/demozwni/hyips.demoscripts.website/tmpl/security.tpl',
      1 => 1455761668,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '13668229725a11378b4c3494_88090822',
  'variables' => 
  array (
    'security' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5a11378b53ae67_15401537',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5a11378b53ae67_15401537')) {
function content_5a11378b53ae67_15401537 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '13668229725a11378b4c3494_88090822';
echo $_smarty_tpl->getSubTemplate ("mheader.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>


<h3>Advanced login security settings:</h3><br><br>

<form method=post>
<input type=hidden name=a value="security">
<input type=hidden name=action value="save">
Detect IP Address Change Sensitivity<br>
<input type=radio name=ip value=disabled <?php if ($_smarty_tpl->tpl_vars['security']->value['detect_ip'] == 'disabled') {?>checked<?php }?>>Disabled<br>
<input type=radio name=ip value=medium <?php if ($_smarty_tpl->tpl_vars['security']->value['detect_ip'] == 'medium') {?>checked<?php }?>>Medium<br>
<input type=radio name=ip value=high <?php if ($_smarty_tpl->tpl_vars['security']->value['detect_ip'] == 'high') {?>checked<?php }?>>High<br><br>

Detect Browser Change<br>
<input type=radio name=browser value=disabled <?php if ($_smarty_tpl->tpl_vars['security']->value['detect_browser'] == 'disabled') {?>checked<?php }?>>Disabled<br>
<input type=radio name=browser value=enabled <?php if ($_smarty_tpl->tpl_vars['security']->value['detect_browser'] == 'enabled') {?>checked<?php }?>>Enabled<br><br>
<input type=submit value="Set" class=sbmt>
</form>


<?php echo $_smarty_tpl->getSubTemplate ("mfooter.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

<?php }
}
?>