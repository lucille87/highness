<?php /* Smarty version 3.1.27, created on 2018-05-17 23:26:01
         compiled from "/home/demozwni/hyips.demoscripts.website/tmpl/header.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:20948215645afe47c976f409_16119048%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3a678ac083e0e24ad003a0f4b7491fd833116f60' => 
    array (
      0 => '/home/demozwni/hyips.demoscripts.website/tmpl/header.tpl',
      1 => 1455749712,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '20948215645afe47c976f409_16119048',
  'variables' => 
  array (
    'settings' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5afe47c9775665_12077135',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5afe47c9775665_12077135')) {
function content_5afe47c9775665_12077135 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/demozwni/hyips.demoscripts.website/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '20948215645afe47c976f409_16119048';
echo $_smarty_tpl->getSubTemplate ("logo.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>


    <div class="dirfaq dirtxt"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>

    <p></p>

    <a class="dirbtn" href="index.php?a=signup">start earning today </a></div>

<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="1349">

  <tr>

    <td width="100%" class="directory"><center>

    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="1200">

      <tr>

        <td width="100%">        

        <div class="dirurl"><a class="dirlink" href="index?a=home">home</a> />></div>

        </td>

      </tr>

    </table>

    </td>

  </tr>

</table>

<br>

<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="1200">

  <tr>

    <td width="100%"><?php }
}
?>