<?php /* Smarty version 3.1.27, created on 2018-05-18 07:08:24
         compiled from "/home/ethgrhjj/investbiliecoin.club/tmpl/mfooter.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:3662715415afeb428822528_55731650%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '31ebc77c2dde1a92bbda2bf56a88c4be8787bd52' => 
    array (
      0 => '/home/ethgrhjj/investbiliecoin.club/tmpl/mfooter.tpl',
      1 => 1455754882,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3662715415afeb428822528_55731650',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5afeb428824be1_29275092',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5afeb428824be1_29275092')) {
function content_5afeb428824be1_29275092 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '3662715415afeb428822528_55731650';
?>
</td>
  </tr>
</table>
<br>












</td>



  </tr>



</table>  



<br>



<center>





<?php echo $_smarty_tpl->getSubTemplate ("footer2.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>