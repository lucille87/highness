<?php /* Smarty version 3.1.27, created on 2018-05-17 08:20:35
         compiled from "/home/demozwni/hyips.demoscripts.website/tmpl/faq.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:11267946645afd7393a4ca69_12414629%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '62b495b8bf9ed8ea6178099b531055a2b7e889e0' => 
    array (
      0 => '/home/demozwni/hyips.demoscripts.website/tmpl/faq.tpl',
      1 => 1455751646,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '11267946645afd7393a4ca69_12414629',
  'variables' => 
  array (
    'settings' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5afd7393ac99e2_14271955',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5afd7393ac99e2_14271955')) {
function content_5afd7393ac99e2_14271955 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/demozwni/hyips.demoscripts.website/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '11267946645afd7393a4ca69_12414629';
echo $_smarty_tpl->getSubTemplate ("logo.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>



<?php echo '<script'; ?>
>

        $(document).ready(function() {

            $('#faq-list .question').click(function() {

                

                $(this).next('.answer').slideToggle(500);

                $(this).toggleClass('close');

                

            });

        }); // end ready

    <?php echo '</script'; ?>
>

    

    <div class="dirfaq dirtxt">Here you found help
    <p></p>

    <a class="dirbtn" href="index.php?a=signup">start earning today </a></div>

<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="1349">

  <tr>

    <td width="100%" class="directory"><center>

    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="1200">

      <tr>

        <td width="100%">        

        <div class="dirurl"><a class="dirlink" href="index?a=home">home</a> / f.a.q</div>

        </td>

      </tr>

    </table>

    </td>

  </tr>

</table>

<br>

<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="1200">

  <tr>

    <td width="100%"><div id="main">

    <div class="container">

    





            <section id="faq-list">

                <h1>ABOUT THE COMPANY</h1>

                  <div class="question">What is <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 Limited?</div>

                <div class="answer">

                    <p>

<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 Limited is Registered British Company and was founded on Jan 2016

                    </p>

                </div>

            

            <br>

                <div class="question">What is the Advantages of joining with <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 Limited</div>

                <div class="answer">

                    <p>

We are committed to provide profitable investment products for our clients. 

                    </p>

                </div>

            

            <br>



                     <h1>ACCOUNT QUESTION</h1>

            

                

                  <div class="question">How can i Invest with <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 Limited?</div>

                <div class="answer">

                    <p>

Investment has been made easy, First you will need to open your personal account and login to your unique members dashboard and you can make your first deposit.

                    </p>

                </div>

            

            <br>

                <div class="question">I forgot my password what should i do?</div>

                <div class="answer">

                    <p>

Our system is automatic, if you forgot your password you can recover your account using our password recovery option, just fill up your email address and answer the security question and you can proceed with your password reset.                    </p>

                </div>

            

            <br>

                <div class="question">Who can participate in your program and do you accept investors from all countries?</div>

                <div class="answer">

                    <p>

Any individual or corporation from any country globally may open an account with us.

                    </p>

                </div>

                <br>

                <div class="question">Do you allow compounding?</div>

                <div class="answer">

                    <p>

No, we do not allow compounding on all investment products.

                    </p>

                </div>

                <br>

                         <h1>DEPOSIT AND WITHDRAWAL</h1>

            

                

                  <div class="question">How long does it take for my deposit to be added to my account?</div>

                <div class="answer">

                    <p>

All deposit are processed INSTANTLY and will be reflected on your personal account dashboard.

                    </p>

                </div>
  <br>
                 <div class="question">Is my Initial Investment/Capital is returned?</div>

                <div class="answer">

                    <p>

All  Principal on our Daily plan will be return, 
Our Expiry Plan does not return the principal deposit, since your principal is already compounded on your income.
                    </p>

                </div>

            

            <br>
               <div class="question">Are my earnings on calendar days?</div>

                <div class="answer">

                    <p>

No earning only on working days.
                    </p>

                </div>

            

            <br>


                <div class="question">How fast you process withdrawals?</div>

                <div class="answer">

                    <p>

All Withdrawal are processed MANUALLY by our Finance department, and will be dispatched within 5 mins - 2 hours after request. Most off the time less then 5 mins.

                    </p>

                </div>

            

            <br>

                <div class="question">What is the minimum withdrawal amount?</div>

                <div class="answer">

                    <p>

Minimum Withdrawl is $0.01 only for neteller this is $5 (limit from neteller self)

                    </p>

                </div>

                <br>

                 <div class="question">Which e-currencies do you accept?</div>

                <div class="answer">

                    <p>

We accept Perfect Money, Payeer, and Bitcoin

                    </p>

                </div>

             <br>   

                 <div class="question">Do you have a Referral Program?</div>

                <div class="answer">

                    <p>

We offer attractive Referral Program, We give 5% Commissions on all deposit made by your direct referrals. 

                    </p>

                </div>

                        
            </section>



        

    </div>

</div>
<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>