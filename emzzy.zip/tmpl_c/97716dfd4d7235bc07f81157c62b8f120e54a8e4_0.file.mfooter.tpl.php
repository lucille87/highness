<?php /* Smarty version 3.1.27, created on 2018-05-14 15:17:47
         compiled from "/home/demozwni/hyips.demoscripts.website/tmpl/mfooter.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:18676254365af9e0dba468a4_06304372%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '97716dfd4d7235bc07f81157c62b8f120e54a8e4' => 
    array (
      0 => '/home/demozwni/hyips.demoscripts.website/tmpl/mfooter.tpl',
      1 => 1455754882,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '18676254365af9e0dba468a4_06304372',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5af9e0dba48c30_84585102',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5af9e0dba48c30_84585102')) {
function content_5af9e0dba48c30_84585102 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '18676254365af9e0dba468a4_06304372';
?>
</td>
  </tr>
</table>
<br>












</td>



  </tr>



</table>  



<br>



<center>





<?php echo $_smarty_tpl->getSubTemplate ("footer2.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>