<?php /* Smarty version 3.1.27, created on 2018-05-18 12:59:12
         compiled from "/home/ethgrhjj/investbiliecoin.club/tmpl/custom/about.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:6322369005aff0660d18c17_99395863%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e0293d7889609e1f56956c09a17fe35c70ecb8de' => 
    array (
      0 => '/home/ethgrhjj/investbiliecoin.club/tmpl/custom/about.tpl',
      1 => 1506220621,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '6322369005aff0660d18c17_99395863',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5aff0660d32ca1_00180579',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5aff0660d32ca1_00180579')) {
function content_5aff0660d32ca1_00180579 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '6322369005aff0660d18c17_99395863';
$_smarty_tpl->tpl_vars["allow"] = new Smarty_Variable("all", null, 0);?>
<?php $_smarty_tpl->tpl_vars["meta_title"] = new Smarty_Variable('', null, 0);?>
<?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

<p>test</p>

<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>