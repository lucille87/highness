<?php /* Smarty version 3.1.27, created on 2018-05-17 23:26:01
         compiled from "/home/demozwni/hyips.demoscripts.website/tmpl/footer.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:8193215715afe47c978f9d6_88669850%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a23cdb7999cac169328352f07f4fe46e037e91f4' => 
    array (
      0 => '/home/demozwni/hyips.demoscripts.website/tmpl/footer.tpl',
      1 => 1455751158,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '8193215715afe47c978f9d6_88669850',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5afe47c9791c21_42460648',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5afe47c9791c21_42460648')) {
function content_5afe47c9791c21_42460648 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '8193215715afe47c978f9d6_88669850';
?>

</td>

  </tr>

</table>

<p>












</td>



  </tr>



</table>  



<br>



<center>


<?php echo $_smarty_tpl->getSubTemplate ("footer2.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>