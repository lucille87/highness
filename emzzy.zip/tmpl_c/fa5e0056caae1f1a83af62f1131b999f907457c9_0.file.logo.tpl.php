<?php /* Smarty version 3.1.27, created on 2018-05-17 23:26:01
         compiled from "/home/demozwni/hyips.demoscripts.website/tmpl/logo.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:12823502495afe47c9777d58_52666147%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fa5e0056caae1f1a83af62f1131b999f907457c9' => 
    array (
      0 => '/home/demozwni/hyips.demoscripts.website/tmpl/logo.tpl',
      1 => 1455776438,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '12823502495afe47c9777d58_52666147',
  'variables' => 
  array (
    'settings' => 0,
    'userinfo' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5afe47c978c027_43499159',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5afe47c978c027_43499159')) {
function content_5afe47c978c027_43499159 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/demozwni/hyips.demoscripts.website/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '12823502495afe47c9777d58_52666147';
?>
<html>

<head>

<meta http-equiv="Content-Language" content="en-us">



<title><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
</title><?php echo '<script'; ?>
 type="text/javascript" src="js/calc.js"><?php echo '</script'; ?>
>





<?php echo '<script'; ?>
 src="js/r.js" type="text/javascript"><?php echo '</script'; ?>
>

<link href="style.css" rel="stylesheet" type="text/css">

<link rel="icon" href="images/icon.ico" type="image/x-icon">

<?php echo '<script'; ?>
 type="text/javascript" src="js/keyboard.js" charset="UTF-8"><?php echo '</script'; ?>
>

<link rel="stylesheet" type="text/css" href="keyboard.css">

<?php echo '<script'; ?>
 type="text/javascript" src="js/tinybox.js"><?php echo '</script'; ?>
>

<?php echo '<script'; ?>
 src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"><?php echo '</script'; ?>
>



<?php echo '<script'; ?>
 type="text/javascript">

  $(document).ready(function () {



      $(window).scroll(function () {

          if ($(this).scrollTop() > 100) {

              $('.scrollup').fadeIn();

          } else {

              $('.scrollup').fadeOut();

          }

      });



      $('.scrollup').click(function () {

          $("html, body").animate({

              scrollTop: 0

          }, 600);

          return false;

      });



  });

<?php echo '</script'; ?>
>





</head>

<body class="bodybg" topmargin="0">



<center>





<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="1349" id="AutoNumber1">

  <tr>

    <td width="100%" class="logotdbg">



<div class="logomenu">

<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="1349">

  <tr>

    <td width="100%">

    <center>

    <table width="1200" border="0" cellspacing="0">

  <tbody>

    <tr>

      <td width="196" height="86"><a href="?a=home"><img src="images/logo.png" alt=""/></a></td>

      <td width="691" align="center" class="logotxtc"><span class="logophone"> +44 20 8144 4065 <a class="logosupport" href="skype:<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
?call">SKYPE: <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
</a></span>
	  <span id="online" class="homeusers"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['info_box_visitor_online_generated']);?>
</span> <span class="homeusers2">Online users</span><span id="acc" class="homeusers"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['info_box_total_accounts_generated']);?>
</span> <span class="homeusers2">Total investors</span></td>

   <?php if ($_smarty_tpl->tpl_vars['userinfo']->value['logged'] != 1) {?>   <td width="230" align="right"><a href="?a=signup" class="logodate">Sign up</a>

         <a class="logologin" style="text-decoration: none" href="?a=login">Login</a>

        </td><?php } else { ?><td width="230" align="right">
        <a href="?a=withdraw" class="logodate2">withdraw</a>

        <a class="logodep" href="?a=deposit" style="text-decoration: none">

        Deposit</a></td><?php }?>

    </tr>

  </tbody>

</table>
<?php if ($_smarty_tpl->tpl_vars['userinfo']->value['logged'] != 1) {?>
<div class="logomenubg">

    <div class="logomenubp"><UL id="menu"><li><a class="current" href="?a=home">Home</a></li>

    




<li><a href='?a=news'>News</a></li>

<li><a href='?a=cust&page=about'>about Our Company</a></li>

<li><a href='?a=cust&page=privacy'>PRIVACY POLICY</a></li>

<li><a href='?a=cust&page=chat'>Shoutbox</a></li>

<li><a href='?a=faq'>F.A.Q</a></li>

<li><a href='?a=rules'>terms of use</a></li>

<li><a href='/?a=rateus' target='new'>Rate us</a></li>

<li><a href='?a=support'>contact us</a></li>

</ul></div></div>
<?php } else { ?><div class="logomenubg">

    <div class="logomenubp"><UL id="menu">
<li><span><a class="current" href="?a=home">Home</a></li>

<li><a href='?a=account'>My Account</a></li>
<li><a href='?a=news'>News</a></li>

<li><a href='?a=cust&page=about'>about Our Company</a></li>

<li><a href='?a=cust&page=privacy'>PRIVACY POLICY</a></li>

<li><a href='?a=cust&page=chat'>Shoutbox</a></li>

<li><a href='?a=faq'>F.A.Q</a></li>

<li><a href='?a=rules'>terms of use</a></li>

<li><a href='/?a=rateus'>Rate us</a></li>

<li><a href='?a=support'>contact us</a></li>

</ul></div></div><?php }?>
</td>

  </tr>

</table>

</div>

<div class="page-wrap1"></div>

<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="1349">



  

</table>



<center>



<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="1200">

  <tr>

    <td width="100%"><center>

    



            
<div class="psh"><?php }
}
?>